package com.example.yourfarm.Service;

import com.example.yourfarm.API.ApiException;
import com.example.yourfarm.Model.Farm;
import com.example.yourfarm.Model.Plant;
import com.example.yourfarm.Repository.FarmRepository;
import com.example.yourfarm.Repository.OrderPlantRepository;
import com.example.yourfarm.Repository.PlantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class PlantService {

    private final PlantRepository plantRepository;
    private final FarmRepository farmRepository;
    private final OrderPlantRepository orderPlantRepository;

    //All
    public List<Plant> getAllPlant(){
        if (plantRepository.findAll().isEmpty())
            throw new ApiException("EmptyList");
        else return plantRepository.findAll();
    }

    //farm
    public void addPlant(Integer farmId , Plant plant){
        Farm farm = farmRepository.findFarmById(farmId);

        if(plantRepository.findPlantByNameAndFarm(plant.getName(), farm)!=null){
            throw new ApiException("can not duplicate plant name");
        }//we don't have plant name unique because multiple farm can have the same plant, but one farm can't duplicate plant name
        plant.setFarm(farm);
        plantRepository.save(plant);

    }

    //farm
    public void update(Integer farmId ,Integer plantId,Plant plant) {
        Plant plant1 = plantRepository.findPlantById(plantId);
        if (plant1 == null) {
            throw new ApiException("Plant not found");
        }
        if (plant1.getFarm().getId() != farmId) {
            throw new ApiException("Can not update this plant");
        }

        plant1.setName(plant.getName());
        plant1.setPrice(plant.getPrice());
        plant1.setQuantity(plant.getQuantity());
        plant1.setType(plant.getType());

        plantRepository.save(plant);

    }

    //farm
    public void deletePlant(Integer farmId , Integer plantId) {
        Plant plant1 = plantRepository.findPlantById(plantId);
        if (plant1 == null) {
            throw new ApiException("Plant not found");
        }
        if (plant1.getFarm().getId() != farmId) {
            throw new ApiException("Can not update this plant");
        }
        plantRepository.delete(plant1);
    }

    //-------------------------- end CRUD  ---------------------------

    public Set<Plant> ViewPlantOfFarm(String farmName) {
        Farm farm1 = farmRepository.findFarmByUserName(farmName);
        if (farm1 == null) {
            throw new ApiException("Farm not found");
        }
        Set<Plant> plants = farm1.getPlants();
        if (plants == null) {
            //  throw new ApiException("Plants not found");
            return Collections.emptySet(); // Return an empty set if no plants found
        }

        return plants;
    }
    //KHLOUD
    public Plant findPlantById(Integer plantId) {
        Plant plant = plantRepository.findPlantById(plantId);

        if (plant == null) {
            throw new ApiException("Plant with id: "+plantId +" not found");
        }
        return plant;
    }

    //Indoor plants|Outdoor plants
//Indoor plants|Outdoor plants
    public  List<Plant> findPlantByType(String type) {


        List<Plant> plant = plantRepository.findPlantByType(type);


//        if(type.equalsIgnoreCase("Indoor plants") || type.equalsIgnoreCase("Outdoor plants")){
//
//        }


        if (plant == null) {
            throw new ApiException("Plants with type"+type +"not found");
        }
        return plant;
    }






}
