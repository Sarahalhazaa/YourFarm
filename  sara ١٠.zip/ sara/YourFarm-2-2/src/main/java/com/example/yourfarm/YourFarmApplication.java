package com.example.yourfarm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YourFarmApplication {

    public static void main(String[] args) {
        SpringApplication.run(YourFarmApplication.class, args);
    }

}
