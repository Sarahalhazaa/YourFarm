package com.example.yourfarm.Service;

import com.example.yourfarm.API.ApiException;
import com.example.yourfarm.DTO.PlantDTO;
import com.example.yourfarm.Model.*;
import com.example.yourfarm.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class    OrderPlantService {

    private final OrderPlantRepository orderPlantRepository;

    private final CustomerRepository customerRepository;
    private final AuthRepository authRepository;
    private final PlantRepository plantRepository;
    private final CompanyRepository companyRepository;
    private final FarmRepository farmRepository;
    private final OrderItemRepository orderItemRepository;


    //ADMIN
    public List<OrderPlant> getAllOrderPlant(){
        if (orderPlantRepository.findAll().isEmpty())
            throw new ApiException("EmptyList");
        else return orderPlantRepository.findAll();
    }


    //CUSTOMER -COMPANY
    //sara

    public OrderPlant OrderPlant(Integer userId, PlantDTO plantDTO) {
        User user = authRepository.findUserById(userId);
        List<OrderItem> orderItems = new ArrayList<>();
        OrderPlant orderPlant = new OrderPlant();
        if(plantDTO.getOrderItems().isEmpty()){
            throw new ApiException("not items");
        }
        OrderItem orderItem = plantDTO.getOrderItems().get(0);

      Plant plant= plantRepository.findPlantById(orderItem.getPlantId());
      if(plant == null){
          throw new ApiException("plant not found");
      }
      Farm farm = farmRepository.findFarmById(plant.getFarm().getId());

        for (OrderItem p : plantDTO.getOrderItems()) {
            Plant plant1= plantRepository.findPlantById(p.getPlantId());
            if (plant1.getFarm().getId() != farm.getId()){
                throw new ApiException(" order can not completed");
            }
        }

        if (user.getRole().equalsIgnoreCase("CUSTOMER")) {
            Customer customer = customerRepository.findCustomerById(userId);
            orderPlant.setCustomer(customer);
        }else if (user.getRole().equalsIgnoreCase("COMPANY")) {
            Company company = companyRepository.findCompanyById(userId);
            orderPlant.setCompany(company);
        }
        orderPlant.setReceivedDateAndTime(plantDTO.getReceivedDateAndTime());
        orderPlant.setStatus("waiting");
        orderPlant.setDateOfOrder(LocalDate.now());
        orderPlant.setPhoneNumber(plantDTO.getPhoneNumber());
        orderPlant.setRegion(plantDTO.getRegion());
        orderPlant.setNationalAddress(plantDTO.getNationalAddress());
        orderPlant.setEvaluation(0.0);
        orderPlant.setTotalPrice(1);
        Integer totalPrice = 0;
        orderPlantRepository.save(orderPlant);

        for (OrderItem p : plantDTO.getOrderItems()) {
            if (plantRepository.findPlantById(p.getPlantId()) == null)
                throw new ApiException(" one plant not found");
            else {
                Plant plant2 = plantRepository.findPlantById(p.getPlantId());
                if (plant2.getQuantity()<p.getQuantity()){
                    throw new ApiException(" Quantity not enough");
                }
                plant.setQuantity(plant2.getQuantity()-p.getQuantity());
                plantRepository.save(plant2);
                OrderItem orderItem1 = new OrderItem(null,p.getPlantId(), p.getQuantity(), plant2.getName(), plant2.getPrice(), orderPlant);
                orderItems.add(orderItem1);
                totalPrice=totalPrice+(plant2.getPrice()*p.getQuantity());
                orderItemRepository.save(orderItem1);
            }
            orderPlant.setOrderItems(orderItems);
            orderPlant.setTotalPrice(totalPrice);
            orderPlant.setFarm(farm);
            orderPlantRepository.save(orderPlant);
        }
        return orderPlant;
    }

    //khaled
    //customer  - company
    public void cancelOrderPlant(Integer userId, Integer orderPlantId){
        User user = authRepository.findUserById(userId);
        OrderPlant orderPlant = orderPlantRepository.findOrderPlantById(orderPlantId);
        List<OrderItem> orderItems = orderPlant.getOrderItems();

        if(user.getRole().equalsIgnoreCase("COMPANY") && orderPlant.getStatus().equalsIgnoreCase("waiting")){
            if (orderPlant.getCompany().getId() == userId){
                    for (OrderItem o : orderItems) {
                        Plant plant2 = plantRepository.findPlantById(o.getPlantId());
                        plant2.setQuantity(plant2.getQuantity() + o.getQuantity());
                        plantRepository.save(plant2);
                    }
                    orderPlant.setStatus("Canceled");
                    orderPlantRepository.save(orderPlant);
            }
        }else if(user.getRole().equalsIgnoreCase("CUSTOMER") && orderPlant.getStatus().equalsIgnoreCase("waiting")){
            if (orderPlant.getCustomer().getId() == userId){
                for (OrderItem o : orderItems) {
                    Plant plant2 = plantRepository.findPlantById(o.getPlantId());
                    plant2.setQuantity(plant2.getQuantity() + o.getQuantity());
                    plantRepository.save(plant2);
                }
                orderPlant.setStatus("Canceled");
                orderPlantRepository.save(orderPlant);
            }
        }else throw new ApiException("invalid request");
    }

//-------------------------------------   end CRUD  ---------------------------

    //sara
    public List<OrderPlant> NewPlantOrders(Integer farmId) {
        ArrayList<OrderPlant> orders2 = new ArrayList<>();
        List<OrderPlant> orders3 = orderPlantRepository.findOrdersByFarmId(farmId);

        if (orders3== null) {
            throw new ApiException(" orders not found");
        }
        for (OrderPlant orders1 : orders3) {
            if (orders1.getStatus().equalsIgnoreCase("Waiting")){
                orders2.add(orders1);
            }}

        return orders2;
    }
//sara
    public List<OrderPlant> currentPlantOrders(Integer userId) {
        ArrayList<OrderPlant> orders2 = new ArrayList<>();
        List<OrderPlant> orders3 = new ArrayList<>();
        User user = authRepository.findUserById(userId);

        if (user.getRole().equalsIgnoreCase("CUSTOMER")) {
            Customer customer = customerRepository.findCustomerById(userId);
            orders3=orderPlantRepository.findOrdersByCustomerId(customer.getId());
            if (orders3== null) {
                throw new ApiException(" orders not found");
            }
            for (OrderPlant orders1 : orders3) {
                if (orders1.getStatus().equalsIgnoreCase("Ready to deliver") || orders1.getStatus().equalsIgnoreCase("accepted") ||orders1.getStatus().equalsIgnoreCase("Waiting")   ){
                    orders2.add(orders1);
                }}

        }else if (user.getRole().equalsIgnoreCase("COMPANY")) {
            Company company = companyRepository.findCompanyById(userId);
            orders3 = orderPlantRepository.findOrdersByCompanyId(company.getId());
            if (orders3== null) {
                throw new ApiException(" orders not found");
            }
            for (OrderPlant orders1 : orders3) {
                if (orders1.getStatus().equalsIgnoreCase("Ready to deliver") || orders1.getStatus().equalsIgnoreCase("accepted") ||orders1.getStatus().equalsIgnoreCase("Waiting")  ){
                    orders2.add(orders1);
                }}
        }
        else if (user.getRole().equalsIgnoreCase("FARM")) {
           Farm farm= farmRepository.findFarmById(userId);
            orders3 = orderPlantRepository.findOrdersByFarmId(farm.getId());
            if (orders3== null) {
                throw new ApiException(" orders not found");
            }
            for (OrderPlant orders1 : orders3) {
                if (orders1.getStatus().equalsIgnoreCase("Ready to deliver") || orders1.getStatus().equalsIgnoreCase("accepted")  ){
                    orders2.add(orders1);
                }}

        }


        return orders2;
    }

//sara
    public List<OrderPlant> previousPlantOrders(Integer userId) {
        List<OrderPlant> orders3 = new ArrayList<>();
        User user = authRepository.findUserById(userId);

        if (user.getRole().equalsIgnoreCase("CUSTOMER")) {
            Customer customer = customerRepository.findCustomerById(userId);
            orders3=orderPlantRepository.findOrdersByCustomerId(customer.getId());

        }else if (user.getRole().equalsIgnoreCase("COMPANY")) {
            Company company = companyRepository.findCompanyById(userId);
            orders3 = orderPlantRepository.findOrdersByCompanyId(company.getId());
        }
        else if (user.getRole().equalsIgnoreCase("FARM")) {
            Farm farm= farmRepository.findFarmById(userId);
            orders3 = orderPlantRepository.findOrdersByFarmId(farm.getId());
        }
        ArrayList<OrderPlant> orders2 = new ArrayList<>();


        if (orders3== null) {
            throw new ApiException(" orders not found");
        }
        for (OrderPlant orders1 : orders3) {
            if (orders1.getStatus().equalsIgnoreCase("Delivered")|| orders1.getStatus().equalsIgnoreCase("Rejected")|| orders1.getStatus().equalsIgnoreCase("Canceled")){
                orders2.add(orders1);
            }}

        return orders2;
    }
//KHLOUD
//public void updateStatusOrderPlant(Integer farmId, Integer orderId) {
//    OrderPlant orderPlant = orderPlantRepository.findOrderPlantById(orderId);
//
//    if (orderPlant == null) {
//        throw new ApiException("orderPlan id not found");
//    }
//    if (orderPlant.getFarm().getId()!= farmId) {
//        throw new ApiException("orderPlant not for you");
//    }
//
//    if (orderPlant.getStatus().equalsIgnoreCase("Rejected")) {
//        throw new ApiException("orderPlant is rejected can not changed");
//    }
//    if (orderPlant.getStatus().equalsIgnoreCase("Delivered")) {
//        throw new ApiException("orderPlant is delivered already");
//    }
//
//    else if (orderPlant.getStatus().equalsIgnoreCase("accepted")) {
//        orderPlant.setStatus("Ready to deliver");
//    } else if (orderPlant.getStatus().equalsIgnoreCase("Ready to deliver")) {
//        orderPlant.setStatus("Delivered");
//    }
//    orderPlantRepository.save(orderPlant);
//}
public void updateStatusOrderPlant(Integer farmId, Integer orderId) {
    OrderPlant orderPlant = orderPlantRepository.findOrderPlantById(orderId);

    if (orderPlant == null) {
        throw new ApiException("orderPlan id not found");
    }
    if (orderPlant.getFarm().getId()!= farmId) {
        throw new ApiException("orderPlant not for you");
    }

    if (orderPlant.getStatus().equalsIgnoreCase("Rejected")) {
        throw new ApiException("orderPlant is rejected can not changed");
    }
    if (orderPlant.getStatus().equalsIgnoreCase("Delivered")) {
        throw new ApiException("orderPlant is delivered already");
    }

    else if (orderPlant.getStatus().equalsIgnoreCase("accepted")) {
        orderPlant.setStatus("Ready to deliver");
    } else if (orderPlant.getStatus().equalsIgnoreCase("Ready to deliver")) {
        orderPlant.setStatus("Delivered");
        orderPlant.getFarm().setSales(orderPlant.getFarm().getSales()+1);
    }
    orderPlantRepository.save(orderPlant);
}

    public void updateOrderPlant(Integer userId,Integer orderPlantId, PlantDTO plantDTO) {
        Integer totalPrice = 0;
        OrderPlant orderPlant = orderPlantRepository.findOrdersById(orderPlantId);
        List<OrderItem> orderItems = orderPlant.getOrderItems();
        List<OrderItem> orderItems1 = plantDTO.getOrderItems();

        User user = authRepository.findUserById(userId);

        if (user.getRole().equalsIgnoreCase("COMPANY")){
            if(!orderPlant.getCompany().getId().equals(userId)){
                throw new ApiException(" can not update order");
            }}else if (user.getRole().equalsIgnoreCase("CUSTOMER")){
            if(!orderPlant.getCustomer().getId().equals(userId)){
                throw new ApiException(" can not update order");
            }
            if (orderPlant.getStatus().equalsIgnoreCase("waiting")) {

                for (OrderItem o : orderItems) {
                    Plant plant2 = plantRepository.findPlantById(o.getPlantId());
                    plant2.setQuantity(plant2.getQuantity() + o.getQuantity());
                    plantRepository.save(plant2);
                }
                orderPlant.setReceivedDateAndTime(plantDTO.getReceivedDateAndTime());
                orderPlant.setPhoneNumber(plantDTO.getPhoneNumber());
                orderPlant.setRegion(plantDTO.getRegion());
                orderPlant.setNationalAddress(plantDTO.getNationalAddress());
                orderPlant.setOrderItems(null);
                orderPlant.setTotalPrice(0);
                orderPlantRepository.save(orderPlant);

                for (OrderItem p : plantDTO.getOrderItems()) {
                    if (plantRepository.findPlantById(p.getPlantId()) == null)
                        throw new ApiException(" one plant not found");
                    else {
                        Plant plant2 = plantRepository.findPlantById(p.getPlantId());
                        if (plant2.getQuantity() < p.getQuantity()) {
                            throw new ApiException(" Quantity not found");
                        }
                        plant2.setQuantity(plant2.getQuantity() - p.getQuantity());
                        plantRepository.save(plant2);
                        OrderItem orderItem3 = new OrderItem(null, plant2.getId(), p.getQuantity(), plant2.getName(), plant2.getPrice(), orderPlant);
                        orderItemRepository.save(orderItem3);
                        orderItems1.add(orderItem3);
                        totalPrice = totalPrice + (plant2.getPrice() * p.getQuantity());
                    }

                }
                orderPlant.setOrderItems(orderItems1);
                orderPlant.setTotalPrice(totalPrice);
                orderPlantRepository.save(orderPlant);
            }
        } else {
            throw new ApiException(" order can not update");
        }
    }


    //KHLOUD
    public void rejectOrderPlant(Integer farmId, Integer orderId) {
        OrderPlant orderPlant = orderPlantRepository.findOrderPlantById(orderId);

        if (orderPlant == null) {
            throw new ApiException("orderPlant id not found");
        }

        if (orderPlant.getFarm().getId() != farmId) {
            throw new ApiException("orderPlant not for you");
        }
        else if (orderPlant.getStatus().equalsIgnoreCase("waiting")) {
            orderPlant.setStatus("Rejected");
            orderPlantRepository.save(orderPlant);
        }else throw new ApiException("invalid request");
    }

    //KHLOUD
    ///3 kh
    public void acceptOrderPlant(Integer farmId, Integer orderId) {
        OrderPlant orderPlant = orderPlantRepository.findOrderPlantById(orderId);

        if (orderPlant == null) {
            throw new ApiException("orderPlant id not found");
        }

        if (orderPlant.getFarm().getId() != farmId)
            throw new ApiException("orderPlant not for you");

        else if (orderPlant.getStatus().equalsIgnoreCase("waiting")) {
            orderPlant.setStatus("accepted");
            orderPlantRepository.save(orderPlant);
        }else throw new ApiException("invalid request");
    }


    //khloud
    public OrderPlant retrieveById( Integer orderId){
        OrderPlant orderPlant = orderPlantRepository.findOrderPlantById(orderId);

        if (orderPlant == null) {
            throw new ApiException("orderPlant id not found");
        }
        return orderPlant;

    }

    //khloud
    public List<OrderPlant> retrieveAllbyStatus(String status){

        List<OrderPlant> orderPlant = orderPlantRepository.findAllByStatus(status);

        if (orderPlant.isEmpty()) {
            throw new ApiException("orderPlant list with status "+status+" empty");
        }
        return orderPlant;

    }

    //khaled
    //customer company
    public void commentOnOrderPlant(Integer userId, Integer orderId, String comment){
        User user = authRepository.findUserById(userId);

        OrderPlant orderPlant = orderPlantRepository.findOrderPlantById(orderId);
        if(orderPlant == null){
            throw new ApiException("order plant not found");
        }

        if(user.getRole().equalsIgnoreCase("COMPANY")){
            if(orderPlant.getCompany().getId()!=userId){
                throw new ApiException("invalid comment request");
            }
        }else if(user.getRole().equalsIgnoreCase("CUSTOMER")){
            if(orderPlant.getCustomer().getId()!=userId){
                throw new ApiException("invalid comment request");
            }
        }
        if(!orderPlant.getStatus().equalsIgnoreCase("Delivered")){
            throw new ApiException("once the order is Delivered you can comment");
        }
        orderPlant.setComment(comment);
        orderPlantRepository.save(orderPlant);
    }

    //sara
    public void evaluationOnOrderPlant(Integer userId, Integer orderId, Double evaluation){
        Double evaluate=0.0;
        Double evaluation1=0.0;
        User user = authRepository.findUserById(userId);
        OrderPlant orderPlant = orderPlantRepository.findOrderPlantById(orderId);

        if(orderPlant == null){
            throw new ApiException("order plant not found");
        }

        if (orderPlant.getEvaluation() != 0.0){
            throw new ApiException("This order has already been evaluated");
        }

        if(!orderPlant.getStatus().equalsIgnoreCase("Delivered")){
            throw new ApiException("invalid evaluation request");
        }
        if (user.getRole().equalsIgnoreCase("COMPANY")){
            if(!orderPlant.getCompany().getId().equals(userId)){
                throw new ApiException("invalid request");
            }}else if (user.getRole().equalsIgnoreCase("CUSTOMER")){
            if(!orderPlant.getCustomer().getId().equals(userId)){
                throw new ApiException("invalid request");
            }
        }

        List<OrderPlant> orderPlants = orderPlantRepository.findOrdersByFarmId(orderPlant.getFarm().getId());
        for (OrderPlant orderPlant1 : orderPlants) {
            if(orderPlant1.getStatus().equalsIgnoreCase("Delivered") && orderPlant1.getEvaluation()!= null){
                evaluate+=orderPlant1.getEvaluation();
            }
        }
        orderPlant.setEvaluation(evaluation);
        orderPlant.getFarm().setNumberOfEvaluation(orderPlant.getFarm().getNumberOfEvaluation()+1);
        evaluation1=(evaluate/orderPlant.getFarm().getNumberOfEvaluation());
        orderPlant.getFarm().setEvaluation(evaluation1);
        orderPlantRepository.save(orderPlant);
        farmRepository.save(orderPlant.getFarm());

    }
}

